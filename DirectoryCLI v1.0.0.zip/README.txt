1# Escreva "commands" para mostrar a lista de comandos

2# Inclusão do arquivo Colorful.Console.dll:
  O aplicativo só funciona com este arquivo no mesmo diretório, caso contrário o aplicativo gera uma exceção (ainda estou corrigindo isso)

3# Comandos:
  Apesar do tópico "1#" já ter essa informação, aqui vai a lista de todos os comandos que pode ser utilizado:

zip
exit
move
list
scan
clear
rename
extract
commands
open-site
system-info
create-file
delete-file
create-folder
delete-folder
del-folders (apaga todas as pastas de um diretório específico)
del-files 
	[parâmetro: 'nenhum' ou 'extensão']
	-nenhum: uso do comando normalmente (<diretório de início> del-files)
	-extensão: quando você usar este parâmetro o programa só vai apagar os arquivos que tiverem esse tipo de extensão
dotnet (compatibilidade com os comandos do dotnet, por exemplo: "dotnet new list")